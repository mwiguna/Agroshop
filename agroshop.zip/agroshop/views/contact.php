<!DOCTYPE html>
<html>
<head>
	<meta name="viewport" content="width=device-width, intial-scale=1">
	<title>Kontak</title>
	<link rel="stylesheet" type="text/css" href="../assets/css/biolife.css">
	<link rel="stylesheet" type="text/css" href="../assets/css/bootstrap.min.css">
</head>
<body>

	<?php include 'nav.php'; ?>

	<div class="main other u-lay">
		<div class="full-float title-other">
			Kontak
		</div>
		<div class="full-float des-other">
			Jika ada pertanyaan seputar cara pembelian atau pun mengenai topik lain. Anda dapat menanyakan langsung pada Customer kami di : <br><br>
			Email : support@agroshopindonesia.com <br>

			<i>@Seputar pertanyaan<br> Anda juga dapat menanyakan perihal khusus dengan menuliskan keterangan bahwa pesan yang anda kirim ditujukan untuk Administrator.</i>
		</div>
	</div>

	<?php include 'footer.php'; ?>

</body>
</html>