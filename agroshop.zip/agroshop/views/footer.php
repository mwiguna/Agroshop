	<div class="full-float footer">
		<div class="author">Copyright &copy; 2016 AGROSHOP INDONESIA. All Rights Reserved.<br>Norman Syarif | M. Wiguna Saputra | Khatami Husaini | Priandi Perdana Putra | Dendhika Kameswara</div>
		<div class="otherfooter">
			<div class="subfoot1">
				<a class="foot-content"><span class="full-float">&raquo; TANAMAN OLAHAN</span></a>
				<a href="product_all.php?product=Kelapa" class="foot-content"><span class="full-float">Kelapa</a></span>
				<a href="product_all.php?product=Pinang" class="foot-content"><span class="full-float">Pinang</a></span>
				<a href="product_all.php?product=Durian" class="foot-content"><span class="full-float">Durian</a></span>
				<a href="product_all.php?product=Kayu Manis" class="foot-content"><span class="full-float">Kayu Manis</a></span>
			</div>
			<div class="subfoot1">
				<a class="foot-content"><span class="full-float">&raquo; PRODUK</span></a>
				<a href="product_all.php?category=Makanan"        class="foot-content"><span class="full-float">Makanan</a></span>
				<a href="product_all.php?category=Obat"           class="foot-content"><span class="full-float">Obat-obatan</a></span>
				<a href="product_all.php?category=Bahan Bangunan" class="foot-content"><span class="full-float">Bahan Bangunan</a></span>
				<a href="product_all.php?category=Bahan Bakar"    class="foot-content"><span class="full-float">Bahan Bakar</a></span>
				<a href="product_all.php?category=Hiasan"         class="foot-content"><span class="full-float">Hiasan</a></span>
			</div>
			<div class="subfoot1">
				<a class="foot-content"><span class="full-float">&raquo; LAINNYA</span></a>
				<a href="faq.php" class="foot-content"><span class="full-float">FAQ</span></a>
				<a href="contact.php" class="foot-content"><span class="full-float">Pertanyaan</span></a>
				<a href="faq.php#pembelian" class="foot-content"><span class="full-float">Cara Melakukan Pembayaran</span></a>
			</div>
		</div>
	</div>
