		<div class="profile1">
			<div class="menu-profile">
				<div class="menu-title-profile">Menu</div>
				<a href="profile.php"><div class="submenu-profile">Biodata</div></a>
				<a href="profile_history.php"><div class="submenu-profile">Riwayat Pembelian</div></a>
				<a href="profile_message.php"><div class="submenu-profile">Pesan</div></a>
				<a href="profile_notification.php"><div class="submenu-profile final">Pemberitahuan</div></a>
			</div>
		</div>