<!DOCTYPE html>
<html>
<head>
	<title>Agroshop Indonesia</title>
	<meta name="viewport" content="width=device-width, intial-scale=1">
	<link rel="stylesheet" type="text/css" href="assets/css/biolife.css">
	<link rel="stylesheet" type="text/css" href="assets/css/bootstrap.min.css">
</head>
<body>


	<div class="main">

	<div class="main-bio full-float">
			<div class="alert alert-success" style="margin: 50px 200px 0 200px; text-align: center; font-size: 24pt; font-family: Constantia;">
				SELAMAT DATANG DI AGROSHOP INDONESIA!<br>PENJUALAN PRODUK HASIL OLAHAN ALAM INDONESIA 
			</div>
			<div class="alert alert-danger" style="margin: 50px 200px 0 200px; text-align: center; font-size: 24pt; font-family: Constantia;">
				Maintenance Server. I'm Sorry :(
			</div>
	</div>


	



	</div>



</body>
</html>